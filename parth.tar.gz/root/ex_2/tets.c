  #include <sys/types.h>
  #include <unistd.h>
  #include <stdio.h>

int main()
  { int i=0;
     pid_t *pid;
 char *str="increment",*no="10", *txt="foo.txt";
     char *const parmList[] = {str,no,txt, NULL};
for(i=0;i<5;i++){
     if ((pid[i] = fork()) == -1)
        perror("fork error");
     else if (pid[i] == 0) {
        execv("increment", parmList);
        printf("Return not expected. Must be an execv error.n");
     }
}
return 1;
  }
