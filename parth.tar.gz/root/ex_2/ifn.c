/* system example : DIR */
#include <stdio.h>      /* printf */
#include <stdlib.h>     /* system, NULL, EXIT_FAILURE */

int main (int argc, char *argv[])
{
pid_t pids[100];
int i,l=0;
int n = 4;

/* Start children. */
 for(i=0;i<n;i++){
    if ((pids[i] = fork()) < 0) {
    perror("fork");
    abort();
    }
    else if (pids[i] == 0)
    { 
//--------------------------------------------------
       for(l=0;l<5;l++)
printf("%d\n",l);
//--------------------------------------------------	

	exit(0);
    }
}

/* Wait for children to exit. */
int status;
pid_t pid;
while (n > 0) {
  pid = wait(&status);
  printf("Child with PID %ld exited with status 0x%x.\n", (long)pid, status);
  --n;  // TODO(pts): Remove pid from the pids array.
}
  return 0;
}