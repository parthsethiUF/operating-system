#include <stdio.h>
#define debug 0

int main(int argc, char *argv[])
{
int line = 1;
int rv, i, first;
FILE *f;

printf("\n--------------------\n");


	    while ( (fscanf(stdin,"%d",&i)) != EOF)
		{
		if((i-first) != 1 && line!=1)
		{
		printf("   %d :   %d\n",line-1,first);
		printf("   %d :   %d\n",line,i);

		}
		first = i;
		line++;
	    	
		}

	    

	(void) printf("--------------------\n");
	return 0;

}
