#include <stdio.h>      
#include <stdlib.h>    
#include <sys/types.h>
#include <unistd.h>
int main (int argc, char *argv[])
{
  pid_t pids[100];
  int n;
  char str[50];
  int i=0;

  char *inc,*no, *txt;
  sscanf(argv[1],"%d",&n);
  sscanf(argv[2],"%[^\n]s",str);


  strtok_r(str," ",&no);
  strtok_r(no," ",&txt);

  printf ("'%s'  '%s' '%s'\n", str, no,txt);
  char *const parmList[] = {str,no,txt, NULL};


 for(i=0;i<n;i++){
    if ((pids[i] = fork()) < 0) {
    perror("fork");
    abort();
    }
    else if (pids[i] == 0)
    { 
//--------------------------------------------------
       execv(str, parmList);
//--------------------------------------------------	

	exit(0);
    }

  }

int status;
pid_t pid;
while (n > 0) {
  pid = wait(&status);
  printf("Child with PID %ld exited with status 0x%x.\n", (long)pid, status);
  --n;
}

 
  return 0;
}